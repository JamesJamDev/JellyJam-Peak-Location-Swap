# CHANGELOG
Version 1.0

- Player is 1/3 their normal height
- Reduced move speed to 80%
- Reduced jump height to around 30%
- Climbs 30% faster
- No fall damage taken due to small size
- Bridges should not break (does not always work)
- Held items scale down in size (cosmetic only)
- Increased item weight slightly
- Backpack slots: 4 -> 3